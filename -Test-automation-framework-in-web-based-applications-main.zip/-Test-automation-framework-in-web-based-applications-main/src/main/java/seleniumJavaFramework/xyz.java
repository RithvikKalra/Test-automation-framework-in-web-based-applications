package seleniumJavaFramework;

public class xyz {

}
